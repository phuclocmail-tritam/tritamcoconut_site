TriTamCoconut starter site. Run: npm install && npm run dev
Replace images in /public/images with real assets.