import React from 'react';
export default function TriTamLanding(){return (
  <div style={{minHeight:'100vh'}}>
    <div className="container" style={{paddingTop:24,paddingBottom:24}}>
      <header style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div style={{display:'flex',gap:12,alignItems:'center'}}>
          <div className="logo">TT</div>
          <div>
            <h1 style={{margin:0,fontSize:18}}>TriTamCoconut</h1>
            <div style={{fontSize:13,color:'rgba(255,255,255,0.95)'}}>Tâm chân thành, vị ngọt lành</div>
          </div>
        </div>
        <nav style={{display:'flex',gap:12}}><a href="#products" style={{color:'inherit',textDecoration:'none'}}>Sản phẩm</a><a href="#about" style={{color:'inherit',textDecoration:'none'}}>Về chúng tôi</a></nav>
      </header>

      <main style={{marginTop:18}}>
        <section style={{display:'grid',gridTemplateColumns:'1fr',gap:16}}>
          <div>
            <h2>Vị ngọt từ tâm – Từ vườn dừa Bến Tre</h2>
            <p>TriTamCoconut mang đến sản phẩm từ dừa tươi và mật hoa dừa, thu hoạch và đóng gói tại Bến Tre – giữ trọn vị ngọt tự nhiên cùng tâm nghề truyền thống.</p>
            <div style={{marginTop:12}}><a className="button" href="#products">Xem sản phẩm</a></div>
          </div>
          <div style={{borderRadius:8,overflow:'hidden'}}>
            <img src="/images/hero-coconut.jpg" alt="hero" style={{width:'100%',height:260,objectFit:'cover'}}/>
          </div>
        </section>

        <section id="products" style={{marginTop:20}}>
          <h3>Sản phẩm</h3>
          <div style={{display:'grid',gridTemplateColumns:'1fr',gap:12}}>
            <div style={{background:'rgba(255,255,255,0.04)',padding:12,borderRadius:8}}>
              <img src="/images/product-coconut.jpg" style={{width:'100%',height:180,objectFit:'cover',borderRadius:6}}/>
              <h4>Dừa Tươi Kim Cương</h4>
              <p>Trái dừa chọn lọc, nước ngọt tự nhiên.</p>
            </div>
            <div style={{background:'rgba(255,255,255,0.04)',padding:12,borderRadius:8}}>
              <img src="/images/product-nectar.jpg" style={{width:'100%',height:180,objectFit:'cover',borderRadius:6}}/>
              <h4>Mật Hoa Dừa</h4>
              <p>Mật hoa dừa thu hoạch tươi, đóng chai thủ công.</p>
            </div>
            <div style={{background:'rgba(255,255,255,0.04)',padding:12,borderRadius:8}}>
              <img src="/images/product-pack.jpg" style={{width:'100%',height:180,objectFit:'cover',borderRadius:6}}/>
              <h4>Combo Quà Tặng</h4>
              <p>Bao bì quà tặng cao cấp, thiết kế riêng.</p>
            </div>
          </div>
        </section>
      </main>

      <footer style={{marginTop:24,borderTop:'1px solid rgba(255,255,255,0.05)',paddingTop:12}}>
        <div style={{display:'flex',justifyContent:'space-between'}}>
          <div>© TriTamCoconut</div>
          <div>Hotline: 0984324942</div>
        </div>
      </footer>
    </div>
  </div>
)};
