import React from 'react';
import { createRoot } from 'react-dom/client';
import TriTamLanding from './components/TriTamLanding';
import './styles.css';
createRoot(document.getElementById('root')).render(<TriTamLanding/>);
